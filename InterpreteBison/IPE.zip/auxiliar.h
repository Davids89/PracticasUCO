#include <stdio.h>


void hacerMinuscula(char * yytext);
char * quitarComillas(char * cadena);